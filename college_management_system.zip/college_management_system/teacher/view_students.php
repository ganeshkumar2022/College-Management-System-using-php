<?php
include_once "student_header.php";
?>
<div class="container mt-5">
  <div class="row">

    <div class="col-sm-12">
      <h3 class="text-center text-primary">View Students</h3>
<table class="table table-bordered">
    <tr class="table-primary">
        <th>S.No</th>
        <th>Student Name</th>
        <th>Department</th>
        <th>Profile Image</th>
        <th>Email</th>
        <th>Mobile</th>
    </tr>
<?php
include_once "../db.php";
$sql="select * from (select * from student where department_id in (select department_id from teacher where tid=:uid))a  left join department c on a.department_id=c.did";
$result=$con->prepare($sql);
$result->bindParam(":uid",$_SESSION['tid']);
$result->execute();
$row=$result->fetchAll(PDO::FETCH_ASSOC);
if(count($row)>0)
{
    foreach($row as $s=>$data)
    {
    ?>
    <tr>
        <td><?=$s+1?></td>
        <td><?=$data['student_name']?></td>
        <td><?=$data['department_name']?></td>
        <td><img src="../admin/<?=$data['profile_image']?>" style="height:100px;width:100px;"></td>
        <td><?=$data['email']?></td>
        <td><?=$data['mobile']?></td>
    </tr>
    <?php
    }
}
else
{
    ?>
    <?php
}
?>
</table>
    </div>
    
  </div>
</div>
<?php
include_once "student_footer.php";
?>