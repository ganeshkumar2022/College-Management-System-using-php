<?php
session_start();

define('base_url','http://localhost/college_management_system/');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Management System</title>
    <link rel="stylesheet" href="<?=base_url?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?=base_url?>assets/css/style.css">
    <script src="<?=base_url?>assets/js/bootstrap.bundle.min.js"></script>
    <script src="<?=base_url?>assets/js/jquery-3.7.1.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
</head>
<body>
<div class="container-fluid p-5 text-white text-center mybg2">
<div style="background-color:rgba(0,0,0,0.3)">
  <h1>College Management System</h1>
  <p>Welcome to Our Collge.</p> 
</div>
</div>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">College Management System</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="admin_login.php">Admin Login</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="student_login.php">Student Login</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="teacher_login.php">Teacher Login</a>
        </li>
      </ul>
    </div>
  </div>
</nav>