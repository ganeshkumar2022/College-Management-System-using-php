<?php
include_once "../db.php";
session_start();
if($_SERVER['REQUEST_METHOD']=="POST")
{
    $cmd=$_POST['cmd'];


    if($cmd=="update_password")
    {
        $password=password_hash($_POST['password'],PASSWORD_DEFAULT);
        $sql="update admin set password=:password where aid=:aid";
        $result=$con->prepare($sql);
        $result->bindParam(":password",$password);
        $result->bindParam(":aid",$_SESSION['aid']);
        

        try
        {
        $result->execute();
        echo "Password updated successfully";
        }
        catch(Exception $e)
        {
            echo "Error to Update a Password";
        }
    }
    if($cmd=="add_fees")
    {
        $department_name=$_POST['department_name'];
        $semester_name=$_POST['semester_name'];
        $amount=$_POST['amount'];
        $sql="insert into fees (department_id,semester,amount) values (:department_name,:semester_name,:amount)";
        $result=$con->prepare($sql);
        $result->bindParam(":department_name",$department_name);
        $result->bindParam(":semester_name",$semester_name);
        $result->bindParam(":amount",$amount);

        try
        {
        $result->execute();
        echo "Fees Added successfully";
        }
        catch(Exception $e)
        {
            echo "Error to Add a Fees";
        }
    }
    if($cmd=="update_student")
    {
        $teacher_name=$_POST['teacher_name'];
        $department_name=$_POST['department_name'];
        $email=$_POST['email'];
        $mobile=$_POST['mobile'];
        $profile_image=$_FILES['profile_image'];
        $education_certificate=$_FILES['education_certificate'];
        $tid=$_POST['tid'];

        $con->beginTransaction();

        

        //check email exist start
        $sql="select * from student where email=:email and tid!=:tid";
        $result=$con->prepare($sql);
        $result->bindParam(":email",$email);
        $result->bindParam(":tid",$tid);
        $result->execute();
        if($row=$result->fetch())
        {
            $con->rollBack();
            echo "Email already exists";
            exit;
        }
        //check email exist end


       
       

         //check mobile exist start
         $sql2="select * from student where mobile=:mobile and tid!=:tid";
         $result2=$con->prepare($sql2);
         $result2->bindParam(":mobile",$mobile);
         $result2->bindParam(":tid",$tid);
         $result2->execute();
         if($result2->fetch())
         {
            
            $con->rollBack();
             echo "Mobile No already exists";
             exit;
         }
         //check mobile exist end

         //get file data db start
         
         $sql345="select * from student where tid=:tid";
         $result3=$con->prepare($sql345);
         $result3->bindParam(":tid",$tid);
         $result3->execute();
         $row23=$result3->fetch();

         //get file data db end

        //image upload start
        if($profile_image['name']!="")
        {
            $teacher_profile="student_profile";
            if(!file_exists($teacher_profile))
            {
                mkdir($teacher_profile,0777,true);
            }
            
            $fileInfo=pathinfo($_FILES['profile_image']['name']);
            $pro_name="profile_picture_".rand(10000,99999).$fileInfo['extension'];
            $upload_file=$teacher_profile."/".$pro_name;

            if(move_uploaded_file($_FILES['profile_image']['tmp_name'],$upload_file))
            {

            }
            else
            {
                $con->rollBack();
                echo "Error to Upload a profile Image";
                exit;
            }
        }
        else
        {
            $upload_file=$row23['profile_image'];
        }
        //image upload end



        //educational certificate upload start
        if($education_certificate['name']!="")
        {
            $education_certificate="student_transfer_certificate";
            if(!file_exists($education_certificate))
            {
                mkdir($education_certificate,0777,true);
            }
            
            $pro_name2="education_certificate_".rand(10000,99999).".pdf";
            $upload_file2=$education_certificate."/".$pro_name2;

            if(move_uploaded_file($_FILES['education_certificate']['tmp_name'],$upload_file2))
            {

            }
            else
            {
                $con->rollBack();
                echo "Error to Upload a Education Certificate";
                exit;
            }
        }
        else
        {
            $upload_file2=$row23['education_certificate'];
        }
        //educational certificate upload end


        $sql="update student set student_name=:teacher_name,department_id=:department_id,email=:email,mobile=:mobile,profile_image=:profile_image,education_certificate=:education_certificate where tid=:tid";
        $result=$con->prepare($sql);
        $result->bindParam(":teacher_name",$teacher_name);
        $result->bindParam(":department_id",$department_name);
        $result->bindParam(":email",$email);
        $result->bindParam(":mobile",$mobile);
        $result->bindParam(":profile_image",$upload_file);
        $result->bindParam(":education_certificate",$upload_file2);
        $result->bindParam(":tid",$tid);

        try
        {
        $result->execute();
        $con->commit();
        echo "Student Data Updated successfully";
        }
        catch(Exception $e)
        {
            $con->rollBack();
            echo "Error to Edit a Student Details";
        }



    }

    if($cmd=="add_student")
    {
        $teacher_name=$_POST['teacher_name'];
        $department_name=$_POST['department_name'];
        $email=$_POST['email'];
        $mobile=$_POST['mobile'];
        $profile_image=$_FILES['profile_image'];
        $education_certificate=$_FILES['education_certificate'];

        $con->beginTransaction();

        

        //check email exist start
        $sql="select * from student where email=:email";
        $result=$con->prepare($sql);
        $result->bindParam(":email",$email);
        $result->execute();
        if($row=$result->fetch())
        {
            $con->rollBack();
            echo "Email already exists";
            exit;
        }
        //check email exist end


       
       

         //check mobile exist start
         $sql2="select * from student where mobile=:mobile";
         $result2=$con->prepare($sql2);
         $result2->bindParam(":mobile",$mobile);
         $result2->execute();
         if($result2->fetch())
         {
            
            $con->rollBack();
             echo "Mobile No already exists";
             exit;
         }
         //check mobile exist end



        //image upload start
        $teacher_profile="student_profile";
        if(!file_exists($teacher_profile))
        {
            mkdir($teacher_profile,0777,true);
        }
        
        $fileInfo=pathinfo($_FILES['profile_image']['name']);
        $pro_name="profile_picture_".rand(10000,99999).$fileInfo['extension'];
        $upload_file=$teacher_profile."/".$pro_name;

        if(move_uploaded_file($_FILES['profile_image']['tmp_name'],$upload_file))
        {

        }
        else
        {
            $con->rollBack();
            echo "Error to Upload a profile Image";
            exit;
        }
        
        //image upload end



        //educational certificate upload start
        $education_certificate="student_transfer_certificate";
        if(!file_exists($education_certificate))
        {
            mkdir($education_certificate,0777,true);
        }
        
        $pro_name2="education_certificate_".rand(10000,99999).".pdf";
        $upload_file2=$education_certificate."/".$pro_name2;

        if(move_uploaded_file($_FILES['education_certificate']['tmp_name'],$upload_file2))
        {

        }
        else
        {
            $con->rollBack();
            echo "Error to Upload a Education Certificate";
            exit;
        }
        
        //educational certificate upload end


        $sql="insert into student (student_name,department_id,email,mobile,profile_image,education_certificate) values (:teacher_name,:department_id,:email,:mobile,:profile_image,:education_certificate)";
        $result=$con->prepare($sql);
        $result->bindParam(":teacher_name",$teacher_name);
        $result->bindParam(":department_id",$department_name);
        $result->bindParam(":email",$email);
        $result->bindParam(":mobile",$mobile);
        $result->bindParam(":profile_image",$upload_file);
        $result->bindParam(":education_certificate",$upload_file2);

        try
        {
        $result->execute();
        $con->commit();
        echo "Student Added successfully";
        }
        catch(Exception $e)
        {
            $con->rollBack();
            echo "Error to Add a Student";
        }



    }

    if($cmd=="update_teacher")
    {
        $teacher_name=$_POST['teacher_name'];
        $department_name=$_POST['department_name'];
        $subject_name=$_POST['subject_name'];
        $email=$_POST['email'];
        $mobile=$_POST['mobile'];
        $profile_image=$_FILES['profile_image'];
        $educational_qualification=$_POST['educational_qualification'];
        $education_certificate=$_FILES['education_certificate'];
        $tid=$_POST['tid'];
        $salary=$_POST['salary'];

        $con->beginTransaction();

        

        //check email exist start
        $sql="select * from teacher where email=:email and tid!=:tid";
        $result=$con->prepare($sql);
        $result->bindParam(":email",$email);
        $result->bindParam(":tid",$tid);
        $result->execute();
        if($row=$result->fetch())
        {
            $con->rollBack();
            echo "Email already exists";
            exit;
        }
        //check email exist end


       
       

         //check mobile exist start
         $sql2="select * from teacher where mobile=:mobile and tid!=:tid";
         $result2=$con->prepare($sql2);
         $result2->bindParam(":mobile",$mobile);
         $result2->bindParam(":tid",$tid);
         $result2->execute();
         if($result2->fetch())
         {
            
            $con->rollBack();
             echo "Mobile No already exists";
             exit;
         }
         //check mobile exist end

         //get file data db start
         
         $sql345="select * from teacher where tid=:tid";
         $result3=$con->prepare($sql345);
         $result3->bindParam(":tid",$tid);
         $result3->execute();
         $row23=$result3->fetch();

         //get file data db end

        //image upload start
        if($profile_image['name']!="")
        {
            $teacher_profile="teacher_profile";
            if(!file_exists($teacher_profile))
            {
                mkdir($teacher_profile,0777,true);
            }
            
            $fileInfo=pathinfo($_FILES['profile_image']['name']);
            $pro_name="profile_picture_".rand(10000,99999).$fileInfo['extension'];
            $upload_file=$teacher_profile."/".$pro_name;

            if(move_uploaded_file($_FILES['profile_image']['tmp_name'],$upload_file))
            {

            }
            else
            {
                $con->rollBack();
                echo "Error to Upload a profile Image";
                exit;
            }
        }
        else
        {
            $upload_file=$row23['profile_image'];
        }
        //image upload end



        //educational certificate upload start
        if($education_certificate['name']!="")
        {
            $education_certificate="education_certificate";
            if(!file_exists($education_certificate))
            {
                mkdir($education_certificate,0777,true);
            }
            
            $pro_name2="education_certificate_".rand(10000,99999).".pdf";
            $upload_file2=$education_certificate."/".$pro_name2;

            if(move_uploaded_file($_FILES['education_certificate']['tmp_name'],$upload_file2))
            {

            }
            else
            {
                $con->rollBack();
                echo "Error to Upload a Education Certificate";
                exit;
            }
        }
        else
        {
            $upload_file2=$row23['education_certificate'];
        }
        //educational certificate upload end


        $sql="update teacher set teacher_name=:teacher_name,department_id=:department_id,subject_id=:subject_id,email=:email,mobile=:mobile,profile_image=:profile_image,educational_qualification=:educational_qualification,education_certificate=:education_certificate,salary=:salary where tid=:tid";
        $result=$con->prepare($sql);
        $result->bindParam(":teacher_name",$teacher_name);
        $result->bindParam(":department_id",$department_name);
        $result->bindParam(":subject_id",$subject_name);
        $result->bindParam(":email",$email);
        $result->bindParam(":mobile",$mobile);
        $result->bindParam(":profile_image",$upload_file);
        $result->bindParam(":educational_qualification",$educational_qualification);
        $result->bindParam(":education_certificate",$upload_file2);
        $result->bindParam(":salary",$salary);
        $result->bindParam(":tid",$tid);

        try
        {
        $result->execute();
        $con->commit();
        echo "Teacher Updated successfully";
        }
        catch(Exception $e)
        {
            $con->rollBack();
            echo "Error to Edit a Teacher Details";
        }



    }

    if($cmd=="add_subject")
    {
        $subject_name=$_POST['subject_name'];
        $sql="insert into subject (subject_name) values (:subject_name)";
        $result=$con->prepare($sql);
        $result->bindParam(":subject_name",$subject_name);

        try
        {
        $result->execute();
        echo "Subject Added successfully";
        }
        catch(Exception $e)
        {
            echo "Error to Add a Subject";
        }
    }
    if($cmd=="add_department")
    {
        $department_name=$_POST['department_name'];
        $sql="insert into department (department_name) values (:department_name)";
        $result=$con->prepare($sql);
        $result->bindParam(":department_name",$department_name);

        try
        {
        $result->execute();
        echo "Department Added successfully";
        }
        catch(Exception $e)
        {
            echo "Error to Add a Department";
        }
    }
    if($cmd=="add_teacher")
    {
        $teacher_name=$_POST['teacher_name'];
        $department_name=$_POST['department_name'];
        $subject_name=$_POST['subject_name'];
        $email=$_POST['email'];
        $mobile=$_POST['mobile'];
        $profile_image=$_FILES['profile_image'];
        $educational_qualification=$_POST['educational_qualification'];
        $education_certificate=$_FILES['education_certificate'];
        $salary=$_POST['salary'];

        $con->beginTransaction();

        

        //check email exist start
        $sql="select * from teacher where email=:email";
        $result=$con->prepare($sql);
        $result->bindParam(":email",$email);
        $result->execute();
        if($row=$result->fetch())
        {
            $con->rollBack();
            echo "Email already exists";
            exit;
        }
        //check email exist end


       
       

         //check mobile exist start
         $sql2="select * from teacher where mobile=:mobile";
         $result2=$con->prepare($sql2);
         $result2->bindParam(":mobile",$mobile);
         $result2->execute();
         if($result2->fetch())
         {
            
            $con->rollBack();
             echo "Mobile No already exists";
             exit;
         }
         //check mobile exist end



        //image upload start
        $teacher_profile="teacher_profile";
        if(!file_exists($teacher_profile))
        {
            mkdir($teacher_profile,0777,true);
        }
        
        $fileInfo=pathinfo($_FILES['profile_image']['name']);
        $pro_name="profile_picture_".rand(10000,99999).$fileInfo['extension'];
        $upload_file=$teacher_profile."/".$pro_name;

        if(move_uploaded_file($_FILES['profile_image']['tmp_name'],$upload_file))
        {

        }
        else
        {
            $con->rollBack();
            echo "Error to Upload a profile Image";
            exit;
        }
        
        //image upload end



        //educational certificate upload start
        $education_certificate="education_certificate";
        if(!file_exists($education_certificate))
        {
            mkdir($education_certificate,0777,true);
        }
        
        $pro_name2="education_certificate_".rand(10000,99999).".pdf";
        $upload_file2=$education_certificate."/".$pro_name2;

        if(move_uploaded_file($_FILES['education_certificate']['tmp_name'],$upload_file2))
        {

        }
        else
        {
            $con->rollBack();
            echo "Error to Upload a Education Certificate";
            exit;
        }
        
        //educational certificate upload end


        $sql="insert into teacher (teacher_name,department_id,subject_id,email,mobile,profile_image,educational_qualification,education_certificate,salary) values (:teacher_name,:department_id,:subject_id,:email,:mobile,:profile_image,:educational_qualification,:education_certificate,:salary)";
        $result=$con->prepare($sql);
        $result->bindParam(":teacher_name",$teacher_name);
        $result->bindParam(":department_id",$department_name);
        $result->bindParam(":subject_id",$subject_name);
        $result->bindParam(":email",$email);
        $result->bindParam(":mobile",$mobile);
        $result->bindParam(":profile_image",$upload_file);
        $result->bindParam(":educational_qualification",$educational_qualification);
        $result->bindParam(":education_certificate",$upload_file2);
        $result->bindParam(":salary",$salary);

        try
        {
        $result->execute();
        $con->commit();
        echo "Teacher Added successfully";
        }
        catch(Exception $e)
        {
            $con->rollBack();
            echo "Error to Add a Teacher";
        }



    }
}

if($_SERVER['REQUEST_METHOD']=="GET")
{
    $cmd=$_GET['cmd'];
    if($cmd=="get_all_subject")
    {
        $sql="select * from subject order by subject_name asc";
        $result=$con->query($sql);
        $a=[];
        while($row=$result->fetch())
        {
            array_push($a,$row);
        }
        echo json_encode($a);
    }
    if($cmd=="get_all_department")
    {
        $sql="select * from department order by department_name asc";
        $result=$con->query($sql);
        $a=[];
        while($row=$result->fetch())
        {
            array_push($a,$row);
        }
        echo json_encode($a);
    }
    if($cmd=="get_all_fees")
    {
        $sql="select b.department_name,a.* from fees a left join department b  on a.department_id=b.did";
        $result=$con->query($sql);
        $a=[];
        while($row=$result->fetch())
        {
            array_push($a,$row);
        }
        echo json_encode($a);
    }
    if($cmd=="get_all_student")
    {
        $sql="select * from student order by student_name asc";
        $result=$con->query($sql);
        $a=[];
        while($row=$result->fetch())
        {
            array_push($a,$row);
        }
        echo json_encode($a);
    }
    if($cmd=="get_one_teacher")
    {
        $tid=$_GET['id'];
        $sql="select * from teacher where tid=:tid";
        $result=$con->prepare($sql);
        $result->bindParam(":tid",$tid);
        $result->execute();
        $row=$result->fetch();
        echo json_encode($row);
    }
    if($cmd=="get_one_student")
    {
        $tid=$_GET['id'];
        $sql="select * from student where tid=:tid";
        $result=$con->prepare($sql);
        $result->bindParam(":tid",$tid);
        $result->execute();
        $row=$result->fetch();
        echo json_encode($row);
    }
    if($cmd=="get_all_teacher")
    {
        $sql="select a.*,b.department_name,c.subject_name from teacher a left join department b on a.department_id=b.did left join subject c on a.subject_id=c.sid order by a.teacher_name asc";
        $result=$con->query($sql);
        $a=[];
        while($row=$result->fetch())
        {
            array_push($a,$row);
        }
        echo json_encode($a);
    }
    if($cmd=="delete_subject")
    {
        $sid=$_GET['id'];
        $sql="delete from subject where sid=:sid";
        $result=$con->prepare($sql);
        $result->bindParam(":sid",$sid);

        try
        {
        $result->execute();
        echo "Subject Deleted successfully";
        }
        catch(Exception $e)
        {
            echo "Error to Delete a Subject";
        }
    }
    if($cmd=="delete_fees")
    {
        $sid=$_GET['id'];
        $sql="delete from fees where fid=:sid";
        $result=$con->prepare($sql);
        $result->bindParam(":sid",$sid);

        try
        {
        $result->execute();
        echo "Fees Deleted successfully";
        }
        catch(Exception $e)
        {
            echo "Error to Delete a Fees";
        }
    }
    if($cmd=="delete_teacher")
    {
        $sid=$_GET['id'];

        //delete teacher profile and educational certificate start
        $sql2="select profile_image,education_certificate from teacher where tid=:sid";
        $result2=$con->prepare($sql2);
        $result2->bindParam(":sid",$sid);
        $result2->execute();
        $row2=$result2->fetch();

        if(file_exists($row2['profile_image']))
        {
            if(unlink($row2['profile_image']))
            {

            }
        }
        else
        {
            exit;
        }

        if(file_exists($row2['education_certificate']))
        {
            if(unlink($row2['education_certificate']))
            {
                
            }
        }
        else
        {
            exit;
        }

        //delete teacher profile and educational certificate end

        
        $sql="delete from teacher where tid=:sid";
        $result=$con->prepare($sql);
        $result->bindParam(":sid",$sid);

        try
        {
        $result->execute();
        echo "Teacher Deleted successfully";
        }
        catch(Exception $e)
        {
            echo "Error to Delete a Teacher";
        }
    }
    if($cmd=="delete_department")
    {
        $did=$_GET['id'];
        $sql="delete from department where did=:did";
        $result=$con->prepare($sql);
        $result->bindParam(":did",$did);

        try
        {
        $result->execute();
        echo "Department Deleted successfully";
        }
        catch(Exception $e)
        {
            echo "Error to Delete a Department";
        }
    }
  

    if($cmd=="delete_student")
    {
        $sid=$_GET['id'];

        //delete student profile and educational certificate start
        $sql2="select profile_image,education_certificate from student where tid=:sid";
        $result2=$con->prepare($sql2);
        $result2->bindParam(":sid",$sid);
        $result2->execute();
        $row2=$result2->fetch();

        if(file_exists($row2['profile_image']))
        {
            if(unlink($row2['profile_image']))
            {

            }
        }
        else
        {
            exit;
        }

        if(file_exists($row2['education_certificate']))
        {
            if(unlink($row2['education_certificate']))
            {
                
            }
        }
        else
        {
            exit;
        }

        //delete student profile and educational certificate end

        
        $sql="delete from student where tid=:sid";
        $result=$con->prepare($sql);
        $result->bindParam(":sid",$sid);

        try
        {
        $result->execute();
        echo "Student Deleted successfully";
        }
        catch(Exception $e)
        {
            echo "Error to Delete a Student";
        }
    }
}
?>