<?php
include_once "admin_header.php";
?>
<div class="container-fluid mt-5">
  <div class="row">

    <div class="col-md-12">

<?php
$api_url="http://localhost/college_management_system/admin/backend.php?cmd=get_all_teacher";
$curl=curl_init($api_url);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);
$response=curl_exec($curl);
curl_close($curl);
?>
<h3 class="text-center text-primary">Manage Teachers</h3>
<table class="table mt-3 table-bordered">
  <tr class="table-primary">
    <th>S.No</th>
    <th>Teacher Name</th>
    <th>Department Name</th>
    <th>Subject Name</th>
    <th>Email</th>
    <th>Mobile</th>
    <th>Profile Image</th>
    <th>Educational qualification</th>
    <th>Educational Certificate</th>
    <th>Salary</th>
    <th>Created at</th>
    <th>Manage</th>
  </tr>
  <?php
  if($response)
  {
    $data=json_decode($response,true);
    foreach($data as $a=>$row)
    {
      ?>
      <tr>
        <td><?=$a+1?></td>
        <td><?=$row['teacher_name']?></td>
        <td><?=$row['department_name']?></td>
        <td><?=$row['subject_name']?></td>
        <td><?=$row['email']?></td>
        <td><?=$row['mobile']?></td>
        <td><img src="<?=$row['profile_image']?>" style="height:100px;width:100px;"></td>
        <td><?=$row['educational_qualification']?></td>
        <td align="center">
          <a href="<?=$row['education_certificate']?>"><img src="../assets/images/pdf.png" style="height:30px;width:30px;"></a>
        </td>
        <td><?=$row['salary']?>&#8377;</td>
        <td><?=$row['created_at']?></td>
        <td>
          <a href="edit_teacher.php?id=<?=$row['tid']?>" class="btn btn-success me-1"><i class="fa-solid fa-edit"></i></a>
          <button type="button" class="btn btn-danger" onclick="delete_teacher('<?=$row['tid']?>')"><i class="fa-solid fa-trash"></i></button>
        </td>
      </tr>
      <?php
    }

    if(count($data)==0)
    {
      ?>
      <tr>
        <td colspan="4" align="center" class="text-danger">No records found</td>
      </tr>
      <?php
    }
  }

  ?>
</table>

    
</div>
  </div>
</div>
<?php
include_once "admin_footer.php";
?>
<script>
  function delete_teacher(a)
  {
    var b=confirm('Are you sure you want to Delete the Teacher');
    if(b)
    {
      $.get("backend.php",{id:a,cmd:"delete_teacher"},function(response){
        alert(response);
        window.location.replace(window.location.href);
      });
    }
    else
    {
      alert('Cancelled successfully');
    }
  }
   
</script>