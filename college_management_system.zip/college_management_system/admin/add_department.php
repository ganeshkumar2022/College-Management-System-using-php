<?php
include_once "admin_header.php";
?>
<div class="container mt-5">
  <div class="row">

    <div class="col-sm-4 offset-4">
    <div class="card">
        <div class="card-body">
      <h3 class="text-center text-primary">Add Department</h3>
      <form action="" id="myform" method="post" autocomplete="off">
  <div class="mb-3 mt-3">
    <label for="department_name" class="form-label">Department Name:</label>
    <input type="text" class="form-control" id="department_name" placeholder="Enter Department Name" name="department_name">
    <span class="department_name_err text-danger"></span>
  </div>
  <div class="d-grid">
  <button type="submit" name="add_department" class="btn btn-primary">Add</button>
  </div>
  <br>
</form>
    </div>
    
    </div>
    </div>
<?php
$api_url="http://localhost/college_management_system/admin/backend.php?cmd=get_all_department";
$curl=curl_init($api_url);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);
$response=curl_exec($curl);
curl_close($curl);
?>
<table class="table mt-3 table-bordered">
  <tr class="table-primary">
    <th>S.No</th>
    <th>Department Name</th>
    <th>Created at</th>
    <th>Manage</th>
  </tr>
  <?php
  if($response)
  {
    $data=json_decode($response,true);
    foreach($data as $a=>$row)
    {
      ?>
      <tr>
        <td><?=$a+1?></td>
        <td><?=$row['department_name']?></td>
        <td><?=$row['created_at']?></td>
        <td>
          <button type="button" class="btn btn-danger" onclick="delete_department('<?=$row['did']?>')"><i class="fa-solid fa-trash"></i></button>
        </td>
      </tr>
      <?php
    }

    if(count($data)==0)
    {
      ?>
      <tr>
        <td colspan="4" align="center" class="text-danger">No records found</td>
      </tr>
      <?php
    }
  }

  ?>
</table>


  </div>
</div>
<?php
include_once "admin_footer.php";
?>
<script>
  function delete_department(a)
  {
    var b=confirm('Are you sure you want to Delete the Department');
    if(b)
    {
      $.get("backend.php",{id:a,cmd:"delete_department"},function(response){
        alert(response);
        window.location.replace(window.location.href);
      });
    }
    else
    {
      alert('Cancelled successfully');
    }
  }
    document.getElementById('myform').addEventListener('submit',function(e){
        e.preventDefault();

        var department_name=document.getElementById('department_name').value;
        var valid=true;

        var namePattern=/^[a-zA-Z\s\.]+$/;

        if(department_name.length==0)
        {
          document.getElementsByClassName('department_name_err')[0].innerHTML="Please enter Department name";
          valid=false;
        }
        else if(!namePattern.test(department_name))
        {
          document.getElementsByClassName('department_name_err')[0].innerHTML="Department name not valid";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('department_name_err')[0].innerHTML="";
        }
        

        if(valid)
        {
           var xhttp=new XMLHttpRequest();
           xhttp.onload=function(){
            alert(this.responseText);
            window.location.replace(window.location.href);
          }
          xhttp.open("POST","backend.php",true);
          xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
          xhttp.send("cmd=add_department&department_name="+department_name);
        }


    });
</script>