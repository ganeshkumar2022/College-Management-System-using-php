<?php
include_once "admin_header.php";

include_once "../db.php";

?>
<div class="container mt-5">
  <div class="row">

    <div class="col-sm-6 offset-3">
    <div class="card">
        <div class="card-body">
      <h3 class="text-center text-primary">Add Student</h3>
      <form action="" id="myform" method="post" autocomplete="off">
<div class="mb-3 mt-3">
    <label for="teacher_name" class="form-label">Student Name:</label>
    <input type="text" class="form-control" id="teacher_name" placeholder="Enter Student Name" name="teacher_name">
    <span class="teacher_name_err text-danger"></span>
  </div>
  <div class="mb-3">
    <label for="department_name" class="form-label">Department Name:</label>
    <select class="form-select" name="department_name" id="department_name">
  <option value="">Choose Department</option>
  <?php
 $sql="select * from department order by department_name asc";
 $result=$con->query($sql);
 while($row=$result->fetch())
 {
    ?>
  <option value="<?=$row['did']?>"><?=$row['department_name']?></option>
    <?php
 }
?>
</select>
    <span class="department_name_err text-danger"></span>
  </div>

  <div class="mb-3">
    <label for="email" class="form-label">Email:</label>
    <input type="text" class="form-control" id="email" placeholder="Enter Email address" name="email">
    <span class="email_err text-danger"></span>
  </div>
  <div class="mb-3">
    <label for="mobile" class="form-label">Mobile:</label>
    <input type="text" class="form-control" id="mobile" maxlength="10" onkeypress="return number_check(event)" placeholder="Enter Mobile No" name="mobile">
    <span class="mobile_err text-danger"></span>
  </div>
  <div class="mb-3">
    <label for="profile_image" class="form-label">Profile Image:</label>
    <input type="file" class="form-control" id="profile_image" name="profile_image">
    <span class="profile_image_err text-danger"></span>
  </div>

  <div class="mb-3">
    <label for="education_certificate" class="form-label">Educational Certificate (TC):</label>
    <input type="file" class="form-control" id="education_certificate"  name="education_certificate">
    <span class="education_certificate_err text-danger"></span>
  </div>


  <div class="d-grid">
  <button type="submit" name="add_teacher" class="btn btn-primary">Add</button>
  </div>
  <br>
</form>
    </div>
    
    </div>
    </div>

<script>
function number_check(e)
{
    if(e.keyCode>=48 && e.keyCode<=57)
    {
      return true;
    }
    return false;
}
</script>

  </div>
</div>
<?php
include_once "admin_footer.php";
?>
<script>
 
    document.getElementById('myform').addEventListener('submit',function(e){
        e.preventDefault();

        var teacher_name=document.getElementById('teacher_name').value;
        var department_name=document.getElementById('department_name').value;
        var email=document.getElementById('email').value;
        var mobile=document.getElementById('mobile').value;
        var profile_image=document.getElementById('profile_image').files[0];
        var education_certificate=document.getElementById('education_certificate').files[0];


        var valid=true;

        var namePattern=/^[a-zA-Z\s\.]+$/;
        var numberPattern=/^\d+$/;
        var emailpattern=/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        var mobilepattern=/^\d{10}$/;

        //teacher name validation start
        if(teacher_name.length==0)
        {
          document.getElementsByClassName('teacher_name_err')[0].innerHTML="Please enter Student name";
          valid=false;
        }
        else if(!namePattern.test(teacher_name))
        {
          document.getElementsByClassName('teacher_name_err')[0].innerHTML="Student name not valid";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('teacher_name_err')[0].innerHTML="";
        }
        //teacher name validation end

        //department name validation start
        if(department_name.length==0)
        {
          document.getElementsByClassName('department_name_err')[0].innerHTML="Please Choose Department name";
          valid=false;
        }
        else if(!numberPattern.test(department_name))
        {
          document.getElementsByClassName('department_name_err')[0].innerHTML="Department name not valid";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('department_name_err')[0].innerHTML="";
        }
        //department name validation end


        //email validation start
        if(email.length==0)
        {
          document.getElementsByClassName('email_err')[0].innerHTML="Please enter email address";
          valid=false;
        }
        else if(!emailpattern.test(email))
        {
          document.getElementsByClassName('email_err')[0].innerHTML="Email field not valid";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('email_err')[0].innerHTML="";
        }
        //email validation end

        //mobile validation start
        if(mobile.length==0)
        {
          document.getElementsByClassName('mobile_err')[0].innerHTML="Please enter mobile no";
          valid=false;
        }
        if(mobile.length!=10)
        {
          document.getElementsByClassName('mobile_err')[0].innerHTML="Mobile no must be 10 digits";
          valid=false;
        }
        else if(!mobilepattern.test(mobile))
        {
          document.getElementsByClassName('mobile_err')[0].innerHTML="Mobile field not valid";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('mobile_err')[0].innerHTML="";
        }
        //mobile validation end


        //profile image validation start
        if(!profile_image)
        {
          document.getElementsByClassName('profile_image_err')[0].innerHTML="Please choose Image file";
          valid=false;
        }
        else if(!profile_image.type.startsWith('image/'))
        {
          document.getElementsByClassName('profile_image_err')[0].innerHTML="Please Choose Image files only";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('profile_image_err')[0].innerHTML="";
        }
        //profile image validation end

        //education_certificate validation start
        if(!education_certificate)
        {
          document.getElementsByClassName('education_certificate_err')[0].innerHTML="Please choose Educational Certificate";
          valid=false;
        }
        else if(education_certificate.type!=="application/pdf")
        {
          document.getElementsByClassName('education_certificate_err')[0].innerHTML="Please Choose PDF files only";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('education_certificate_err')[0].innerHTML="";
        }
        //education_certificate validation end
        

        if(valid)
        {
          const formdata=new FormData(this);
          formdata.append('cmd','add_student');

          var xhttp=new XMLHttpRequest();
           xhttp.onload=function(){
            alert(this.responseText);
            window.location.replace(window.location.href);
          }
          xhttp.open("POST","backend.php",true);
          //xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
          xhttp.send(formdata);
        }


    });
</script>