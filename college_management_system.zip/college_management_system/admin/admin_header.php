<?php
session_start();
if(!isset($_SESSION['aid']))
{
  header("Location:../admin_login.php");
  exit;
}
define('base_url','http://localhost/college_management_system/');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Management System</title>
    <link rel="stylesheet" href="<?=base_url?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?=base_url?>assets/css/style.css">
    <script src="<?=base_url?>assets/js/bootstrap.bundle.min.js"></script>
    <script src="<?=base_url?>assets/js/jquery-3.7.1.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
</head>
<body class="ladmin-bg">
<nav class="navbar navbar-expand-sm bg-primary navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Admin Panel</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="dashboard.php">Dashboard</a>
        </li>
        <li class="nav-item dropdown">
  <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Teacher</a>
  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="add_teacher.php">Add Teacher</a></li>
    <li><a class="dropdown-item" href="manage_teacher.php">Manage Teacher</a></li>
  </ul>
</li>
<li class="nav-item dropdown">
  <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Student</a>
  <ul class="dropdown-menu">
     <li><a class="dropdown-item" href="add_student.php">Add Student</a></li>
    <li><a class="dropdown-item" href="manage_student.php">Manage Student</a></li>
  </ul>
</li>

        <li class="nav-item">
          <a class="nav-link" href="add_department.php">Add Department</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_subject.php">Add Subject</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="fees_assign.php">Fees Assign</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="update_password.php">Update Password</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>