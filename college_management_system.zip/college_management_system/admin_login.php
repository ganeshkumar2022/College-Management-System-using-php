<?php
include_once "header.php";
?>
<div class="container mt-5">
  <div class="row">
    <div class="col-sm-4">
    </div>
    <div class="col-sm-4">
      <div class="card">
  <div class="card-body">
  <h3 class="text-center text-primary">Admin Login</h3>
  <form action="" method="post" autocomplete="off">
  <div class="mb-3 mt-3">
    <label for="email" class="form-label">Email:</label>
    <input type="text" class="form-control" id="email" placeholder="Enter email" name="email">
  </div>
  <div class="mb-3">
    <label for="password" class="form-label">Password:</label>
    <input type="password" class="form-control" id="password" placeholder="Enter password" name="password">
  </div>
  <div class="d-grid">
  <button type="submit" name="admin_login" class="btn btn-primary">Login</button>
  </div>
</form>
  </div>
</div>
    </div>
    <div class="col-sm-4">
    </div>
  </div>
</div>
<script>
    $(document).ready(function(){
        $("body").css("background-color","snowwhite");
    });
</script>
<?php
include_once "footer.php";

if(isset($_POST['admin_login']))
{
  $email=trim($_POST['email']);
  $password=trim($_POST['password']);

  if(empty($email))
  {
    ?>
    <script>
      alert('Please enter Email');
    </script>
    <?php
    exit;
  }
  elseif(!filter_var($email,FILTER_VALIDATE_EMAIL))
  {
    ?>
    <script>
      alert('Email is not Valid');
    </script>
    <?php
    exit;
  }

  if(empty($password))
  {
    ?>
    <script>
      alert('Please enter Password');
    </script>
    <?php
    exit;
  }


  include_once "db.php";

  $sql="select * from admin where email=:email";
  $result=$con->prepare($sql);
  $result->bindParam(":email",$email);
  $result->execute();
  if($row=$result->fetch(PDO::FETCH_ASSOC))
  {
    if(password_verify($password,$row['password']))
    {
      $_SESSION['aid']=$row['aid'];
      ?>
      <script>
        alert('Login Successfully');
        window.location.replace('admin/dashboard.php');
      </script>
      <?php
      exit;
    }
    else
    {
      ?>
      <script>
        alert('Email or Password incorrect');
      </script>
      <?php
      exit;
    }
  }
  else
  {
    ?>
    <script>
      alert('Email or Password incorrect');
    </script>
    <?php
    exit;
  }
}
?>