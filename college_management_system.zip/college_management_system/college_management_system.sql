-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 25, 2025 at 05:13 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `college_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `email`, `password`, `created_at`) VALUES
(1, 'admin@gmail.com', '$2y$10$jwJ51vKiq1oGuoWbngzpwu9kGtks.LCzt5awjxEO1pIThrr4PZpaW', '2025-02-23 07:55:44');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `did` int(11) NOT NULL,
  `department_name` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`did`, `department_name`, `created_at`) VALUES
(1, 'BCA', '2025-02-06 10:34:41'),
(2, 'MSC', '2025-02-06 10:34:46'),
(4, 'Commerce', '2025-02-06 10:34:53'),
(5, 'Science', '2025-02-06 10:34:57'),
(6, 'English', '2025-02-06 10:35:01'),
(7, 'Maths', '2025-02-06 10:35:04'),
(8, 'Microbiology', '2025-02-06 10:35:11'),
(9, 'BBA', '2025-02-06 10:35:14');

-- --------------------------------------------------------

--
-- Table structure for table `fees`
--

CREATE TABLE `fees` (
  `fid` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `semester` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fees`
--

INSERT INTO `fees` (`fid`, `department_id`, `semester`, `amount`, `created_at`) VALUES
(1, 1, 1, 10000, '2025-02-23 07:28:04'),
(2, 1, 2, 17000, '2025-02-23 07:28:20');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `tid` int(11) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `department_id` int(11) NOT NULL,
  `email` varchar(60) NOT NULL,
  `mobile` char(10) NOT NULL,
  `profile_image` varchar(100) NOT NULL,
  `education_certificate` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `password` varchar(100) NOT NULL DEFAULT '12345'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`tid`, `student_name`, `department_id`, `email`, `mobile`, `profile_image`, `education_certificate`, `created_at`, `password`) VALUES
(9, 'uja', 1, 'jeni2@gmail.com', '8567567568', 'student_profile/profile_picture_16592jpg', 'student_transfer_certificate/education_certificate_17595.pdf', '2025-02-24 16:51:20', 'jeni@123'),
(10, 'mahesh', 1, 'mahesh@gmail.com', '8564564564', 'student_profile/profile_picture_13727jpg', 'student_transfer_certificate/education_certificate_19408.pdf', '2025-02-23 07:57:37', '12345'),
(11, 'santhosh', 2, 'santhosh@gmail.com', '9456456456', 'student_profile/profile_picture_44851jpg', 'student_transfer_certificate/education_certificate_95455.pdf', '2025-02-23 07:57:40', '12345'),
(14, 'sam', 1, 'sam@gmail.com', '9355453453', 'student_profile/profile_picture_58389jpg', 'student_transfer_certificate/education_certificate_13695.pdf', '2025-02-24 16:16:57', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `sid` int(11) NOT NULL,
  `subject_name` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`sid`, `subject_name`, `created_at`) VALUES
(1, 'Maths', '2025-02-06 05:11:45'),
(6, 'PHP', '2025-02-06 05:12:37'),
(8, 'Python', '2025-02-06 05:12:47'),
(10, 'Java', '2025-02-06 05:36:30'),
(11, 'Tamil', '2025-02-06 05:36:36'),
(12, 'Accounts', '2025-02-06 05:36:41'),
(13, 'Micro biology', '2025-02-06 05:36:46'),
(14, 'English', '2025-02-06 05:36:53');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `tid` int(11) NOT NULL,
  `teacher_name` varchar(50) NOT NULL,
  `department_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `email` varchar(60) NOT NULL,
  `mobile` char(10) NOT NULL,
  `profile_image` varchar(100) NOT NULL,
  `educational_qualification` varchar(50) NOT NULL,
  `education_certificate` varchar(100) NOT NULL,
  `salary` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `password` varchar(100) NOT NULL DEFAULT '12345'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`tid`, `teacher_name`, `department_id`, `subject_id`, `email`, `mobile`, `profile_image`, `educational_qualification`, `education_certificate`, `salary`, `created_at`, `password`) VALUES
(4, 'soundarya', 1, 6, 'sound@gmail.com', '9674576467', 'teacher_profile/profile_picture_40979jpg', 'mcom', 'education_certificate/education_certificate_84577.pdf', 20000, '2025-02-25 16:12:43', '123'),
(5, 'kajal', 6, 14, 'kajal@gmail.com', '9678678678', 'teacher_profile/profile_picture_78149jpg', 'BBA', 'education_certificate/education_certificate_95108.pdf', 15000, '2025-02-23 07:57:00', '12345'),
(8, 'jh', 4, 10, 'kj@gmail.com', '6988697897', 'teacher_profile/profile_picture_66635jpg', 'reth', 'education_certificate/education_certificate_14333.pdf', 19000, '2025-02-23 07:57:03', '12345'),
(9, 'michael', 1, 14, 'michael@gmail.com', '9345345345', 'teacher_profile/profile_picture_35369PNG', 'mca', 'education_certificate/education_certificate_44743.pdf', 25000, '2025-02-25 16:02:16', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `fees`
--
ALTER TABLE `fees`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`sid`),
  ADD UNIQUE KEY `subject_name` (`subject_name`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`tid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `fees`
--
ALTER TABLE `fees`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
