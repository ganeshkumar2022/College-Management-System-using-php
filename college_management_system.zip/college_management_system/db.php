<?php
$servername="localhost";
$username="root";
$pass="";
$database="college_management_system";
$str="mysql:host=$servername;dbname=$database";
//con start
try
{
   $con=new PDO($str,$username,$pass);
   $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   //echo "Connected";
}
catch(PDOException $e)
{
    die("Error :".$e->getMessage());
}
//con end
?>