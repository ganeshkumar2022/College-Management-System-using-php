<?php
include_once "admin_header.php";

include_once "../db.php";
$sql_dep="select * from department order by department_name asc";
$res_dep=$con->query($sql_dep);
$res_dep->execute();
$row22=$res_dep->fetchAll();
?>

<div class="container mt-5">
  <div class="row">

    <div class="col-sm-4 offset-4">
    <div class="card">
        <div class="card-body">
      <h3 class="text-center text-primary">Update Password</h3>
      <form action="" id="myform" method="post" autocomplete="off">

  <div class="mb-3 mt-3">
    <label for="password" class="form-label">New Password:</label>
    <input type="password" class="form-control" id="password" placeholder="Enter new password" name="password">
    <span class="password_err text-danger"></span>
  </div>
  <div class="d-grid">
  <button type="submit" name="update_password" class="btn btn-primary">Update</button>
  </div>
  <br>
</form>
    </div>
    
    </div>
    </div>


  </div>
</div>
<?php
include_once "admin_footer.php";
?>
<script>
  function delete_fees(a)
  {
    var b=confirm('Are you sure you want to Delete the Fees');
    if(b)
    {
      $.get("backend.php",{id:a,cmd:"delete_fees"},function(response){
        alert(response);
        window.location.replace(window.location.href);
      });
    }
    else
    {
      alert('Cancelled successfully');
    }
  }
    document.getElementById('myform').addEventListener('submit',function(e){
        e.preventDefault();

        var password=document.getElementById('password').value;
        var valid=true;

        var passwordPattern=/^(?=.*[a-zA-Z])(?=.*\d)(?=.*[\W_]).+$/;


        

        
        if(password.length==0)
        {
          document.getElementsByClassName('password_err')[0].innerHTML="Please enter Password";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('password_err')[0].innerHTML="";
        }

       
       
        

        if(valid)
        {
          
           var xhttp=new XMLHttpRequest();
           xhttp.onload=function(){
            alert(this.responseText);
            window.location.replace(window.location.href);
          }
          xhttp.open("POST","backend.php",true);
          xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
          xhttp.send("cmd=update_password&password="+password);
        }


    });
</script>