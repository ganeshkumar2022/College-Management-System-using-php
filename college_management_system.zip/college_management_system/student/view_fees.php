<?php
include_once "student_header.php";
?>
<div class="container mt-5">
  <div class="row">

    <div class="col-sm-12">
      <h3 class="text-center text-primary">View Fees struture</h3>
<table class="table table-bordered">
    <tr class="table-primary">
        <th>S.No</th>
        <th>Department</th>
        <th>Semester</th>
        <th>Fees</th>
    </tr>
<?php
include_once "../db.php";
$sql="select a.department_id,b.department_name,a.semester,a.amount from (select * from fees where department_id in (select department_id from student where tid=:uid))a left join department b on a.department_id=b.did";
$result=$con->prepare($sql);
$result->bindParam(":uid",$_SESSION['uid']);
$result->execute();
$row=$result->fetchAll(PDO::FETCH_ASSOC);
if(count($row)>0)
{
    foreach($row as $s=>$data)
    {
    ?>
    <tr>
        <td><?=$s+1?></td>
        <td><?=$data['department_name']?></td>
        <td><?=$data['semester']?></td>
        <td><?=$data['amount']?>&#8377;</td>
    </tr>
    <?php
    }
}
else
{
    ?>
    <?php
}
?>
</table>
    </div>
    
  </div>
</div>
<?php
include_once "student_footer.php";
?>