<?php
include_once "../db.php";
session_start();
if($_SERVER['REQUEST_METHOD']=="POST")
{
    $cmd=$_POST['cmd'];


    if($cmd=="update_password")
    {
        $password=$_POST['password'];
        $sql="update student set password=:password where tid=:aid";
        $result=$con->prepare($sql);
        $result->bindParam(":password",$password);
        $result->bindParam(":aid",$_SESSION['uid']);
        

        try
        {
        $result->execute();
        echo "Password updated successfully";
        }
        catch(Exception $e)
        {
            echo "Error to Update a Password";
        }
    }
}

?>