<?php
include_once "admin_header.php";

include_once "../db.php";
$sql_dep="select * from department order by department_name asc";
$res_dep=$con->query($sql_dep);
$res_dep->execute();
$row22=$res_dep->fetchAll();
?>
<script>
  function num_check(e)
  {
    if(e.keyCode>=48 && e.keyCode<=57)
    {
      return true; 
    }
    return false;
  }
</script>
<div class="container mt-5">
  <div class="row">

    <div class="col-sm-4 offset-4">
    <div class="card">
        <div class="card-body">
      <h3 class="text-center text-primary">Add Fees</h3>
      <form action="" id="myform" method="post" autocomplete="off">
  <div class="mb-3 mt-3">
    <label for="department_name" class="form-label">Department Name:</label>
    <select class="form-select" id="department_name" name="department_name">
      <option value="">Choose Department name</option>
      <?php
      foreach($row22 as $data)
      {
        ?>
        <option value="<?=$data['did']?>"><?=$data['department_name']?></option>
        <?php
      }
      ?>
    </select>
    <span class="department_name_err text-danger"></span>
  </div>
  <div class="mb-3 mt-3">
    <label for="semester_name" class="form-label">Semester:</label>
    <select class="form-select" id="semester_name" name="semester_name">
    <option value="">Choose semester</option>
    <option>1</option>
    <option>2</option>
    <option>3</option>
    <option>4</option>
    <option>5</option>
    <option>6</option>
  </select>
    <span class="semester_name_err text-danger"></span>
  </div>
  <div class="mb-3 mt-3">
    <label for="amount" class="form-label">Fees Amount:</label>
    <input type="text" class="form-control" id="amount" onkeypress="return num_check(event)" placeholder="Enter Amount" name="amount">
    <span class="amount_err text-danger"></span>
  </div>
  <div class="d-grid">
  <button type="submit" name="add_fees" class="btn btn-primary">Add</button>
  </div>
  <br>
</form>
    </div>
    
    </div>
    </div>
<?php
$api_url="http://localhost/college_management_system/admin/backend.php?cmd=get_all_fees";
$curl=curl_init($api_url);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);
$response=curl_exec($curl);
curl_close($curl);
?>
<table class="table mt-3 table-bordered">
  <tr class="table-primary">
    <th>S.No</th>
    <th>Department Name</th>
    <th>Semester Name</th>
    <th>Fees</th>
    <th>Created at</th>
    <th>Manage</th>
  </tr>
  <?php
  if($response)
  {
    $data=json_decode($response,true);
    foreach($data as $a=>$row)
    {
      ?>
      <tr>
        <td><?=$a+1?></td>
        <td><?=$row['department_name']?></td>
        <td><?=$row['semester']?></td>
        <td><?=$row['amount']?>&#8377;</td>
        <td><?=$row['created_at']?></td>
        <td>
          <button type="button" class="btn btn-danger" onclick="delete_fees('<?=$row['fid']?>')"><i class="fa-solid fa-trash"></i></button>
        </td>
      </tr>
      <?php
    }

    if(count($data)==0)
    {
      ?>
      <tr>
        <td colspan="4" align="center" class="text-danger">No records found</td>
      </tr>
      <?php
    }
  }

  ?>
</table>


  </div>
</div>
<?php
include_once "admin_footer.php";
?>
<script>
  function delete_fees(a)
  {
    var b=confirm('Are you sure you want to Delete the Fees');
    if(b)
    {
      $.get("backend.php",{id:a,cmd:"delete_fees"},function(response){
        alert(response);
        window.location.replace(window.location.href);
      });
    }
    else
    {
      alert('Cancelled successfully');
    }
  }
    document.getElementById('myform').addEventListener('submit',function(e){
        e.preventDefault();

        var department_name=document.getElementById('department_name').value;
        var semester_name=document.getElementById('semester_name').value;
        var amount=document.getElementById('amount').value;
        var valid=true;

        var namePattern=/^[a-zA-Z\s\.]+$/;
        var numpattern=/^[0-9]+$/;

        if(department_name.length==0)
        {
          document.getElementsByClassName('department_name_err')[0].innerHTML="Please Choose Department name";
          valid=false;
        }
        else if(!numpattern.test(department_name))
        {
          document.getElementsByClassName('department_name_err')[0].innerHTML="Department name not valid";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('department_name_err')[0].innerHTML="";
        }

        
        if(semester_name.length==0)
        {
          document.getElementsByClassName('semester_name_err')[0].innerHTML="Please Choose Semester name";
          valid=false;
        }
        else if(!numpattern.test(semester_name))
        {
          document.getElementsByClassName('semester_name_err')[0].innerHTML="Semester name not valid";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('semester_name_err')[0].innerHTML="";
        }

        if(semester_name.length==0)
        {
          document.getElementsByClassName('semester_name_err')[0].innerHTML="Please Choose Semester name";
          valid=false;
        }
        else if(!numpattern.test(semester_name))
        {
          document.getElementsByClassName('semester_name_err')[0].innerHTML="Semester name not valid";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('semester_name_err')[0].innerHTML="";
        }

        if(amount.length==0)
        {
          document.getElementsByClassName('amount_err')[0].innerHTML="Please enter amount";
          valid=false;
        }
        else if(!numpattern.test(amount))
        {
          document.getElementsByClassName('amount_err')[0].innerHTML="amount format not valid";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('amount_err')[0].innerHTML="";
        }
        

        if(valid)
        {
          
           var xhttp=new XMLHttpRequest();
           xhttp.onload=function(){
            alert(this.responseText);
            window.location.replace(window.location.href);
          }
          xhttp.open("POST","backend.php",true);
          xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
          xhttp.send("cmd=add_fees&department_name="+department_name+"&semester_name="+semester_name+"&amount="+amount);
        }


    });
</script>