<?php
include_once "admin_header.php";

include_once "../db.php";

?>
<div class="container mt-5">
  <div class="row">

    <div class="col-sm-6 offset-3">
    <div class="card">
        <div class="card-body">
        <?php
$api_url="http://localhost/practice/college_management_system/admin/backend.php?cmd=get_one_teacher&id=".$_GET['id'];
$curl=curl_init($api_url);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);
$response=curl_exec($curl);
curl_close($curl);

$data=json_decode($response,true);
?>
      <h3 class="text-center text-primary">Edit Teacher</h3>
      <form action="" id="myform" method="post" autocomplete="off">
<div class="mb-3 mt-3">
    <label for="teacher_name" class="form-label">Teacher Name:</label>
    <input type="text" class="form-control" id="teacher_name" value="<?=$data['teacher_name']?>" placeholder="Enter Teacher Name" name="teacher_name">
    <span class="teacher_name_err text-danger"></span>
  </div>
  <div class="mb-3">
    <label for="department_name" class="form-label">Department Name:</label>
    <select class="form-select" name="department_name" id="department_name">
  <option value="">Choose Department</option>
  <?php
 $sql="select * from department order by department_name asc";
 $result=$con->query($sql);
 while($row=$result->fetch())
 {
    ?>
  <option value="<?=$row['did']?>" <?=$data['department_id']==$row['did']?'selected':''?>><?=$row['department_name']?></option>
    <?php
 }
?>
</select>
    <span class="department_name_err text-danger"></span>
  </div>
  <div class="mb-3">
    <label for="subject_name" class="form-label">Subject Name:</label>
    <select class="form-select" name="subject_name" id="subject_name">
  <option value="">Choose Subject</option>
<?php
 $sql="select * from subject order by subject_name asc";
 $result=$con->query($sql);
 while($row=$result->fetch())
 {
    ?>
  <option value="<?=$row['sid']?>" <?=$data['subject_id']==$row['sid']?'selected':''?>><?=$row['subject_name']?></option>
    <?php
 }
?>
</select>
    <span class="subject_name_err text-danger"></span>
  </div>
  <div class="mb-3">
    <label for="email" class="form-label">Email:</label>
    <input type="text" class="form-control" id="email" value="<?=$data['email']?>" placeholder="Enter Email address" name="email">
    <span class="email_err text-danger"></span>
  </div>
  <div class="mb-3">
    <label for="mobile" class="form-label">Mobile:</label>
    <input type="text" class="form-control" id="mobile" value="<?=$data['mobile']?>" maxlength="10" onkeypress="return number_check(event)" placeholder="Enter Mobile No" name="mobile">
    <span class="mobile_err text-danger"></span>
  </div>
  <div class="mb-3">
    <label for="profile_image" class="form-label">Profile Image:</label>
    <input type="file" class="form-control" id="profile_image" name="profile_image">
    <span class="profile_image_err text-danger"></span>
  </div>
  <div class="mb-3">
    <label for="educational_qualification" class="form-label">Educational Qualification:</label>
    <input type="text" class="form-control" id="educational_qualification" value="<?=$data['educational_qualification']?>" placeholder="Enter Educational Qualification" name="educational_qualification">
    <span class="educational_qualification_err text-danger"></span>
  </div>
  <div class="mb-3">
    <label for="education_certificate" class="form-label">Educational Certificate (higher level):</label>
    <input type="file" class="form-control" id="education_certificate"  name="education_certificate">
    <span class="education_certificate_err text-danger"></span>
  </div>
  <div class="mb-3">
    <label for="salary" class="form-label">Salary:</label>
    <input type="text" class="form-control" id="salary" onkeypress="return number_check(event)" value="<?=$data['salary']?>" placeholder="Enter Salary" name="salary">
    <span class="salary_err text-danger"></span>
  </div>
<input type="hidden" id="tid" name="tid" value="<?=$data['tid']?>">
  <div class="d-grid">
  <button type="submit" name="add_teacher" class="btn btn-primary">Update</button>
  </div>
  <br>
</form>
    </div>
    
    </div>
    </div>

<script>
function number_check(e)
{
    if(e.keyCode>=48 && e.keyCode<=57)
    {
      return true;
    }
    return false;
}
</script>

  </div>
</div>
<?php
include_once "admin_footer.php";
?>
<script>
  function delete_department(a)
  {
    var b=confirm('Are you sure you want to Delete the Department');
    if(b)
    {
      $.get("backend.php",{id:a,cmd:"delete_department"},function(response){
        alert(response);
        window.location.replace(window.location.href);
      });
    }
    else
    {
      alert('Cancelled successfully');
    }
  }
    document.getElementById('myform').addEventListener('submit',function(e){
        e.preventDefault();

        var teacher_name=document.getElementById('teacher_name').value;
        var department_name=document.getElementById('department_name').value;
        var subject_name=document.getElementById('subject_name').value;
        var email=document.getElementById('email').value;
        var mobile=document.getElementById('mobile').value;
        var profile_image=document.getElementById('profile_image').files[0];
        var educational_qualification=document.getElementById('educational_qualification').value;
        var education_certificate=document.getElementById('education_certificate').files[0];
        var salary=document.getElementById('salary').value;
        var tid=document.getElementById('tid').value;


        var valid=true;

        var namePattern=/^[a-zA-Z\s\.]+$/;
        var numberPattern=/^\d+$/;
        var emailpattern=/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        var mobilepattern=/^\d{10}$/;

        //teacher name validation start
        if(teacher_name.length==0)
        {
          document.getElementsByClassName('teacher_name_err')[0].innerHTML="Please enter Teacher name";
          valid=false;
        }
        else if(!namePattern.test(teacher_name))
        {
          document.getElementsByClassName('teacher_name_err')[0].innerHTML="Teacher name not valid";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('teacher_name_err')[0].innerHTML="";
        }
        //teacher name validation end

        //department name validation start
        if(department_name.length==0)
        {
          document.getElementsByClassName('department_name_err')[0].innerHTML="Please Choose Department name";
          valid=false;
        }
        else if(!numberPattern.test(department_name))
        {
          document.getElementsByClassName('department_name_err')[0].innerHTML="Department name not valid";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('department_name_err')[0].innerHTML="";
        }
        //department name validation end

        //subject name validation start
        if(subject_name.length==0)
        {
          document.getElementsByClassName('subject_name_err')[0].innerHTML="Please Choose Subject name";
          valid=false;
        }
        else if(!numberPattern.test(subject_name))
        {
          document.getElementsByClassName('subject_name_err')[0].innerHTML="Subject name not valid";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('subject_name_err')[0].innerHTML="";
        }
        //subject name validation end

        //email validation start
        if(email.length==0)
        {
          document.getElementsByClassName('email_err')[0].innerHTML="Please enter email address";
          valid=false;
        }
        else if(!emailpattern.test(email))
        {
          document.getElementsByClassName('email_err')[0].innerHTML="Email field not valid";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('email_err')[0].innerHTML="";
        }
        //email validation end

        //mobile validation start
        if(mobile.length==0)
        {
          document.getElementsByClassName('mobile_err')[0].innerHTML="Please enter mobile no";
          valid=false;
        }
        if(mobile.length!=10)
        {
          document.getElementsByClassName('mobile_err')[0].innerHTML="Mobile no must be 10 digits";
          valid=false;
        }
        else if(!mobilepattern.test(mobile))
        {
          document.getElementsByClassName('mobile_err')[0].innerHTML="Mobile field not valid";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('mobile_err')[0].innerHTML="";
        }
        //mobile validation end

        //educational_qualification validation start
        if(educational_qualification.length==0)
        {
          document.getElementsByClassName('educational_qualification_err')[0].innerHTML="Please enter educational qualification";
          valid=false;
        }
        else if(!namePattern.test(educational_qualification))
        {
          document.getElementsByClassName('educational_qualification_err')[0].innerHTML="Educational qualification field not valid";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('educational_qualification_err')[0].innerHTML="";
        }
        //educational_qualification validation end

         //salary validation start
         if(salary.length==0)
        {
          document.getElementsByClassName('salary_err')[0].innerHTML="Please enter your salary";
          valid=false;
        }
        else if(!numberPattern.test(salary))
        {
          document.getElementsByClassName('salary_err')[0].innerHTML="Salary Format not valid";
          valid=false;
        }
        else
        {
          document.getElementsByClassName('salary_err')[0].innerHTML="";
        }
        //salary validation end


        //profile image validation start
        if(profile_image)
        {
            if(!profile_image.type.startsWith('image/'))
            {
            document.getElementsByClassName('profile_image_err')[0].innerHTML="Please Choose Image files only";
            valid=false;
            }
            else
            {
            document.getElementsByClassName('profile_image_err')[0].innerHTML="";
            }
        }
       
        //profile image validation end

        //education_certificate validation start
        if(education_certificate)
        {
            if(education_certificate.type!=="application/pdf")
            {
            document.getElementsByClassName('education_certificate_err')[0].innerHTML="Please Choose PDF files only";
            valid=false;
            }
            else
            {
            document.getElementsByClassName('education_certificate_err')[0].innerHTML="";
            }
        }
       
        //education_certificate validation end
        

        if(valid)
        {
          const formdata=new FormData(this);
          formdata.append('cmd','update_teacher');

          var xhttp=new XMLHttpRequest();
           xhttp.onload=function(){
            alert(this.responseText);
            window.location.replace('manage_teacher.php');
          }
          xhttp.open("POST","backend.php",true);
          //xhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
          xhttp.send(formdata);
        }


    });
</script>