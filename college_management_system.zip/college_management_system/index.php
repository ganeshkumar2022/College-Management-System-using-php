<?php
include_once "header.php";
?>
<div class="container mt-5">
  <div class="row">
    <div class="col-sm-3">
    </div>
    <div class="col-sm-6">
      <h3 class="text-primary text-center fw-bold">Mohana's College of Arts & Science</h3>
      <img src="assets/images/college1.jpg" class="mx-auto d-block my-4">
    </div>
    <div class="col-sm-3">
    </div>
  </div>
</div>
<?php
include_once "footer.php";
?>